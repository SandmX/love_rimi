__author__ = 'Sandmeyer<sandmx.work@gmail.com>'
__version__ = '0.0.1.3'
__license__ = 'GNU v3.0'


from pathlib import Path

LANG_F_DIR = Path(__file__).parent / 'lang'
