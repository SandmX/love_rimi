__author__ = 'Sandmeyer<sandmx.work@gmail.com>'
__version__ = '0.0.1.3'
__license__ = 'GNU v3.0'
